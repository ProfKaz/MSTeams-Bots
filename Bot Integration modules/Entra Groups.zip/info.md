# Microsoft Entra Integration

> **To get started:**  
> You must first execute: `!kazbot init Microsoft Entra`  
> This is required to initialize the integration and unlock Microsoft Entra queries.

---

This module connects to Microsoft Entra to retrieve group and membership statistics.

## Capabilities
- Count groups by type (Microsoft 365, Security, Distribution, etc.)
- Count total members per group

## Prerequisites
- App registration with proper permissions
- Environment file `.env.msEntra`

---

> **Tip:**  
> Use `!kazbot help Microsoft Entra` to get a detailed list of available commands and features for this integration module.

---
