// main.js
try {
  require('@microsoft/microsoft-graph-client');
  require('isomorphic-fetch');
  require('dotenv');
} catch (e) {
  throw new Error(
    "\nMissing required dependencies for Microsoft Entra integration.\n" +
    "Please run the following command at your project root:\n\n" +
    "npm install @microsoft/microsoft-graph-client isomorphic-fetch dotenv\n"
  );
}

// Use require.main.require to ensure dependencies are loaded from the project root
const { Client } = require.main.require('@microsoft/microsoft-graph-client');
require.main.require('isomorphic-fetch');
require.main.require('dotenv').config({ path: __dirname + '/.env.msEntra' });

const clientId = process.env.MS_ENTRA_CLIENT_ID;
const clientSecret = process.env.MS_ENTRA_CLIENT_SECRET;
const tenantId = process.env.MS_ENTRA_TENANT_ID;

let initialized = false; // Track state for status()

async function getAccessToken() {
  const url = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
  const params = new URLSearchParams();
  params.append('grant_type', 'client_credentials');
  params.append('client_id', clientId);
  params.append('client_secret', clientSecret);
  params.append('scope', 'https://graph.microsoft.com/.default');

  const response = await fetch(url, { method: 'POST', body: params });
  const data = await response.json();
  return data.access_token;
}

function getGraphClient(token) {
  return Client.init({
    authProvider: (done) => done(null, token)
  });
}

async function fetchGroupsData() {
  const accessToken = await getAccessToken();
  const client = getGraphClient(accessToken);
  let groups = [];
  let response = await client.api('/groups').top(999).get();
  groups = groups.concat(response.value);
  while (response['@odata.nextLink']) {
    response = await client.api(response['@odata.nextLink']).get();
    groups = groups.concat(response.value);
  }
  const summary = {
    totalGroups: groups.length,
    byType: {
      'Microsoft 365': 0,
      'Security': 0,
      'SecurityMailEnabled': 0,
      'Distribution': 0
    },
    membersPerGroup: {}
  };
  for (const group of groups) {
    if (group.groupTypes.includes('Unified')) summary.byType['Microsoft 365']++;
    else if (group.securityEnabled && group.mailEnabled) summary.byType['SecurityMailEnabled']++;
    else if (group.securityEnabled) summary.byType['Security']++;
    else if (group.mailEnabled) summary.byType['Distribution']++;
    // Fetch member count per group (optional: optimize with batch requests)
    const members = await client.api(`/groups/${group.id}/members/$count`).header('ConsistencyLevel', 'eventual').get();
    summary.membersPerGroup[group.displayName] = members;
  }
  return summary;
}

// Add after your other methods:



module.exports = {
  name: "Microsoft Entra Integration",
  description: "Fetches group statistics from Microsoft Entra",
  async init() {
    // You could add a connectivity check here if needed
    initialized = true;
    return true;
  },
  async close() {
    initialized = false;
    return true;
  },
  async status() {
    return initialized ? "initialized" : "not initialized";
  },
  async restart() {
    await this.close();
    await this.init();
    return "restarted";
  },
  async run() {
    try {
      if (!initialized) return { error: "Module not initialized. Use '!kazbot init Microsoft Entra' first." };
      const data = await fetchGroupsData();
      return data;
    } catch (error) {
      return { error: error.message };
    }
  },
async ask(question) {
  const q = question.toLowerCase();

  // 1. Total groups
  if (
    q.includes('how many groups') ||
    q.includes('number of groups') ||
    q.match(/count (all )?groups/) ||
    q.includes('total groups')
  ) {
    const stats = await this.run();
    if (stats.error) return `Error: ${stats.error}`;
    return `There are ${stats.totalGroups} groups in Microsoft Entra.`;
  }

  // 2. Split or breakdown by type
  if (
    q.includes('split number of groups by type') ||
    q.includes('split groups by type') ||
    q.includes('groups by type') ||
    q.includes('breakdown') ||
    q.includes('how many of each group type') ||
    q.match(/group(s)? (types|by type)/)
  ) {
    const stats = await this.run();
    if (stats.error) return `Error: ${stats.error}`;
    return [
      `There are ${stats.totalGroups} groups in total:`,
      `- Microsoft 365 groups: ${stats.byType['Microsoft 365']}`,
      `- Security groups: ${stats.byType['Security']}`,
      `- Security Mail-Enabled groups: ${stats.byType['SecurityMailEnabled']}`,
      `- Distribution lists: ${stats.byType['Distribution']}`
    ].join('\n');
  }

  // 3. Specific group type counts (normalize question to match possible user language)
  if (
    q.match(/(how many|number of|count)\s*(m365|microsoft 365|office 365)[ -]?groups?/) ||
    q.match(/(how many|number of|count)\s*security[ -]?groups?/) ||
    q.match(/(how many|number of|count)\s*distribution[ -]?lists?/) ||
    q.match(/(how many|number of|count)\s*mail[ -]?enabled[ -]?groups?/)
  ) {
    const stats = await this.run();
    if (stats.error) return `Error: ${stats.error}`;
    if (q.includes('m365') || q.includes('microsoft 365') || q.includes('office 365')) {
      return `There are ${stats.byType['Microsoft 365']} Microsoft 365 groups.`;
    }
    if (q.includes('security mail')) {
      return `There are ${stats.byType['SecurityMailEnabled']} security mail-enabled groups.`;
    }
    if (q.includes('security')) {
      return `There are ${stats.byType['Security']} security groups.`;
    }
    if (q.includes('distribution')) {
      return `There are ${stats.byType['Distribution']} distribution lists.`;
    }
  }

  // Optionally, add even more Q&A patterns or advanced NLP here

  return "I don't understand the question. Try asking about total groups, split by type, or a specific type of group (Microsoft 365, security, etc).";
}

};
