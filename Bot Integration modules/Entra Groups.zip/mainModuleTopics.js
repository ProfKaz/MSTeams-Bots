// services/Microsoft Entra/mainModuleTopics.js
module.exports = [
  "entra", "microsoft entra", "azure ad", "aad",
  "group", "groups", "security group", "distribution list",
  "m365 group", "office 365 group", "type of group",
  "membership", "mail-enabled group", "number of groups", "total groups"
  // Add other relevant terms or phrases here
];
