# Microsoft Entra Integration Commands

Use the following commands to interact with this module:

- `!kazbot init Microsoft Entra`  
  Initialize and connect to Microsoft Entra.

- `!kazbot close Microsoft Entra`  
  Close the connection and unload the module.

- `!kazbot status Microsoft Entra`  
  Show the current status of the integration.

- `!kazbot restart Microsoft Entra`  
  Restart the integration module.

- `!kazbot help Microsoft Entra`  
  Show this help information.

---

## Module Analytics and Export (session-aware)

- `show analytics`  
  Display session-wide analytics, including when Microsoft Entra was active.

- `!kazbot show session analytics`  
  Show analytics (e.g., number of prompts, answers, files) only from the time Microsoft Entra was initiated to when it was closed.

- `!kazbot export session answers`  
  Export only answers generated while Microsoft Entra was active (Markdown).

- `!kazbot export session memory`  
  Export only session memory items from the active Microsoft Entra session window(s) (Markdown).

- `!kazbot export session prompts`  
  Export only prompts (user questions) from the active Microsoft Entra session window(s) (Markdown).

---

## Ask Natural Questions!

Once the integration is initialized, you can ask questions such as:
- "How many groups are there?"
- "Show number of security groups."
- "How many Microsoft 365 groups do I have?"

The bot will answer using **live Microsoft Entra data** when available.

---
