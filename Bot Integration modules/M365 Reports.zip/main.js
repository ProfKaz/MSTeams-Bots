// main.js
const getBaseUrl = require('../../utils/getBaseUrl');

try {
  require('@microsoft/microsoft-graph-client');
  require('isomorphic-fetch');
  require('dotenv');
  require('fs');
  require('path');
} catch (e) {
  throw new Error(
    "\nMissing required dependencies for M365 Reports integration.\n" +
    "Please run the following command at your project root:\n\n" +
    "npm install @microsoft/microsoft-graph-client isomorphic-fetch dotenv\n"
  );
}

const fs = require('fs');
const path = require('path');

// Always reload .env.reports with override on module require/reload
['CLIENT_ID', 'CLIENT_SECRET', 'TENANT_ID'].forEach(k => delete process.env[k]);
require('dotenv').config({ path: __dirname + '/.env.reports', override: true });

const clientId = process.env.CLIENT_ID;
const clientSecret = process.env.CLIENT_SECRET;
const tenantId = process.env.TENANT_ID;

let initialized = false;

// Authentication
async function getAccessToken() {
  const url = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
  const params = new URLSearchParams();
  params.append('grant_type', 'client_credentials');
  params.append('client_id', clientId);
  params.append('client_secret', clientSecret);
  params.append('scope', 'https://graph.microsoft.com/.default');
  const response = await fetch(url, { method: 'POST', body: params });
  const data = await response.json();
  if (!data.access_token) {
    throw new Error(
      'Failed to obtain Microsoft Graph access token.\n' +
      'Error: ' + JSON.stringify(data, null, 2)
    );
  }
  return data.access_token;
}

// Supported reports
const availableReports = [
  {
    name: "Email Activity",
    path: "/reports/getEmailActivityUserDetail(period='D30')",
    description: "User-level email activity for the last 30 days"
  },
  {
    name: "Teams User Activity",
    path: "/reports/getTeamsUserActivityUserDetail(period='D30')",
    description: "Teams user activity for the last 30 days"
  },
  {
    name: "OneDrive Usage",
    path: "/reports/getOneDriveUsageAccountDetail(period='D30')",
    description: "OneDrive account usage for the last 30 days"
  },
  {
    name: "SharePoint Site Usage",
    path: "/reports/getSharePointSiteUsageDetail(period='D30')",
    description: "SharePoint site-level activity for the last 30 days"
  }
];

// Fetch the report as CSV (raw text)
async function fetchReport(reportPath) {
  const accessToken = await getAccessToken();
  const url = `https://graph.microsoft.com/v1.0${reportPath}`;
  const response = await fetch(url, {
    method: 'GET',
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!response.ok) throw new Error(`Graph API call failed: ${response.statusText}`);
  const csvText = await response.text();
  return csvText;
}

// Render a Markdown preview table and append a download link
function previewCSV(csv, downloadUrl, maxRows = 3, maxCols = 8) {
  const lines = csv.trim().split('\n');
  if (lines.length < 2) return 'No data available for this report.';

  // Split headers and limit columns
  const headers = lines[0].split(',').slice(0, maxCols).map(h => h.trim());
  const rows = lines
    .slice(1, maxRows + 1)
    .map(line =>
      line.split(',').slice(0, maxCols).map(cell => cell.trim())
    );

  // Build Markdown table
  let output = '| ' + headers.join(' | ') + ' |\n';
  output += '| ' + headers.map(() => '---').join(' | ') + ' |\n';
  rows.forEach(row => {
    // Pad missing cells
    while (row.length < headers.length) row.push('');
    output += '| ' + row.join(' | ') + ' |\n';
  });

  output += `\n_Showing up to ${Math.min(maxRows, lines.length - 1)} rows and ${headers.length} columns._`;
  if (downloadUrl) {
    output += `\n\n[⬇️ Download full CSV](${downloadUrl})`;
  }
  return output;
}

module.exports = {
  name: "M365 Reports Integration",
  description: "Fetches usage and activity reports from Microsoft 365 via Graph.",
  async init() {
    initialized = true;
    return true;
  },
  async close() {
    initialized = false;
    return true;
  },
  async status() {
    return initialized ? "initialized" : "not initialized";
  },
  async restart() {
    await this.close();
    await this.init();
    return "restarted";
  },
  async run(reportName = "", context = null) {
  try {
    if (!initialized) return { error: "Module not initialized. Use '!kazbot init M365 Reports' first." };
    if (!reportName) {
      return {
        availableReports: availableReports.map(r => ({
          name: r.name,
          description: r.description
        }))
      };
    }
    const report = availableReports.find(r => r.name.toLowerCase() === reportName.toLowerCase());
    if (!report) return { error: `Report '${reportName}' not found.` };
    const csv = await fetchReport(report.path);

    // Save CSV to a temp file (unique filename)
    const safeName = report.name.replace(/[^a-zA-Z0-9]/g, '');
    const filename = `M365Reports-${safeName}-${Date.now()}.csv`;
    const publicDir = path.resolve(__dirname, '../../public');
    if (!fs.existsSync(publicDir)) {
      fs.mkdirSync(publicDir, { recursive: true });
    }
    const filepath = path.join(publicDir, filename);
    fs.writeFileSync(filepath, csv, 'utf8');

    // Dynamic download link
    const baseUrl = getBaseUrl(context);
    const downloadUrl = `${baseUrl}/download/${filename}`;

    return { report: report.name, data: previewCSV(csv, downloadUrl) };
  } catch (error) {
    return { error: error.message };
  }
},
  async ask(question, context = null) {
    const q = question.toLowerCase();

    // List all available reports
    if (
      q.includes('list reports') ||
      q.includes('available reports') ||
      q.includes('what reports') ||
      q.includes('show reports')
    ) {
      const { availableReports } = await this.run("", context);
      if (!availableReports || !availableReports.length) return "No reports available.";
      return [
        `List of Available M365 Reports:`,
        ...availableReports.map(r => `- ${r.name}: ${r.description}`)
      ].join('\n');
    }

    // Email Activity
    if (q.match(/email activity/)) {
      const res = await this.run("Email Activity", context);
      if (res.error) return `Error: ${res.error}`;
      return `**Email Activity Report (last 30 days):**\n${res.data}`;
    }

    // Teams User Activity
    if (q.match(/teams (user )?activity/)) {
      const res = await this.run("Teams User Activity", context);
      if (res.error) return `Error: ${res.error}`;
      return `**Teams User Activity Report (last 30 days):**\n${res.data}`;
    }

    // OneDrive Usage
    if (q.match(/onedrive (usage|activity)/)) {
      const res = await this.run("OneDrive Usage", context);
      if (res.error) return `Error: ${res.error}`;
      return `**OneDrive Usage Report (last 30 days):**\n${res.data}`;
    }

    // SharePoint Site Usage
    if (q.match(/sharepoint (site )?(usage|activity)/)) {
      const res = await this.run("SharePoint Site Usage", context);
      if (res.error) return `Error: ${res.error}`;
      return `**SharePoint Site Usage Report (last 30 days):**\n${res.data}`;
    }

    // Default
    return "I don't understand the question. Try asking to list available reports, or to show Email Activity, Teams Activity, OneDrive Usage, or SharePoint Site Usage reports.";
  }
};
