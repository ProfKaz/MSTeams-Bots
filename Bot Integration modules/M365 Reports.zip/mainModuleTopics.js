// services/M365Reports/mainModuleTopics.js
module.exports = [
  "report", "reports", "graph reports", "m365 reports", "microsoft 365 reports", "usage report",
  "activity report", "email activity", "teams usage", "onedrive activity",
  "office 365 usage", "graph api reports", "report details", "list reports", "show report"
];
