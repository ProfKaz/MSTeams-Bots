# M365 Reports – Integration Commands

Use the following commands to interact with this module:

* `!kazbot init M365 Reports`
  Initialize and connect to M365 Reports.

* `!kazbot close M365 Reports`
  Close the connection and unload the module.

* `!kazbot status M365 Reports`
  Show the current status of the integration.

* `!kazbot restart M365 Reports`
  Restart the integration module.

* `!kazbot help M365 Reports`
  Show this help information.

---

## Module Analytics and Export (session-aware)

* `show analytics`
  Display session-wide analytics, including when M365 Reports was active.

* `!kazbot show session analytics`
  Show analytics (e.g., number of prompts, answers, files) only from the time the M365 Reports module was initiated to when it was closed.

* `!kazbot export session answers`
  Export only answers generated while this module was active (Markdown).

* `!kazbot export session memory`
  Export only session memory items from the active M365 Reports session window(s) (Markdown).

* `!kazbot export session prompts`
  Export only prompts (user questions) from the active M365 Reports session window(s) (Markdown).

---

## Ask Natural Questions!

Once the integration is initialized, you can ask questions such as:

* "List all available M365 reports."
* "Show the last 7 days of Teams user activity."
* "Give me the OneDrive file activity report."
* "How many users sent emails last week?"

The bot will answer using **live M365 Reports data** from Microsoft Graph when available.

---

**Folder: M365Reports**
