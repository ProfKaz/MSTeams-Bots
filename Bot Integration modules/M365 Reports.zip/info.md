# M365 Reports Integration

> **To get started:**  
> First, run: `!kazbot init M365 Reports`  
> Initialization is required to authenticate and enable Microsoft 365 Reports queries.

---

This module integrates with Microsoft Graph to fetch various reports on Microsoft 365 usage, activity, and statistics (Exchange, Teams, OneDrive, SharePoint, etc.).

## Capabilities
- List all available M365 Reports endpoints
- Retrieve and summarize specific usage/activity reports
- Query for user/email/Teams/OneDrive/SharePoint statistics

## Prerequisites
- Microsoft 365 tenant with reporting data
- Azure AD App registration with `Reports.Read.All` or relevant permissions
- Environment file `.env.purview` or `.env.m365reports` with relevant secrets and endpoints

---

> **Tip:**  
> Use `!kazbot help M365 Reports` to get a detailed list of available commands and integration features.

---
